Starting with the Basics of python, I learnt about various libraries useful for machine learning like numpy for maths, array and vectorization, pandas for data handling and CSV file handleing.

Learnt Matplotlib and Seaborn to visualize the dataset and Sckit learn for implementing machine learning algorithms.

Solved a follow back assignment to gain a firm gripe on the concept learnt so far.

In the third week learnt about various machine learning methodologies and there real life application.

Learnt basic about the regression and classification model in supervised learning and bit of clustering in unsupervised learning.

Then learnt about the yfinance library and application of supervised learning to define a algorithm for the same.

Solved a follow on assignment for the same containing real life application for linear regression model, logistic regression model and yfinance implementation.

The course flow has taught me the real life implementation of machine learning and how to intergrate finance with it to achieve algo trading.
